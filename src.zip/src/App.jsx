// import { useEffect, useState } from 'react'

// function App() {
//   const [message, setMessage] = useState("Loading...");

//   useEffect(() => {
//     fetch('http://localhost:3001/api/hello')
//       .then(res => res.json())
//       .then(data => setMessage(data.message))
//       .catch(err => setMessage("Lỗi khi kết nối backend"));
//   }, []);

//   return (
//     <div>
//       <h1>Frontend gọi Backend</h1>
//       <p>Thông điệp từ server: <strong>{message}</strong></p>
//     </div>
//   );
// }

// export default App;
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import SanPham from './components/SanPham';
import UuDai from './components/UuDai';
import ChiTietSanPham from './components/ChiTietSanPham';
import SanPhamChiTiet from './components/SanPhamChiTiet';
import Login from "./components/Login";
import Register from "./components/Register";
import Profile from "./components/Profile";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SearchResults from './components/SearchResults'; 
// import VisaCategoryPage from './components/VisaCategoryPage';

function App() {
  return (
    <BrowserRouter>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
      />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/san-pham" element={<SanPham />} />
        <Route path="/san-pham/:cardId" element={<ChiTietSanPham />} />
        <Route path="/product/:slug" element={<SanPhamChiTiet />} />
        {/* <Route path="/san-pham" element={<SanPham />} /> */}
        <Route path="/uu-dai" element={<UuDai />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/search" element={<SearchResults />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
