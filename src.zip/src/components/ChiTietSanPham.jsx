import { useParams, useNavigate, Link } from "react-router-dom";
import { Home } from "lucide-react";
import Navbar from './Navbar';
import React, { useState } from "react";

// const [selectedProduct, setSelectedProduct] = useState(null);
import { CARD_MAP } from "./visaCardData"; // đường dẫn phù hợp với project của bạn

// const CARD_MAP = {
//   1: {
//     title: "Visa Hoàn Tiền",
//     description: "Hoàn tiền cho ăn uống, mua sắm hằng ngày.",
//     products: [
//       {
//         name: "Thẻ Hoàn Tiền 1%",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],        
//         gia: "Miễn phí",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//       {
//         name: "Thẻ Super Cashback",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "299.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//     ],
//   },
//   2: {
//     title: "Visa Du Lịch",
//     description: "Thẻ tối ưu cho người đi du lịch và công tác.",
//     products: [
//       {
//         name: "Travel Easy",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "399.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//       {
//         name: "Thẻ Du Lịch Quốc Tế",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "599.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//     ],
//   },
//   3: {
//     title: "Visa Doanh Nghiệp",
//     description: "Quản lý chi tiêu và tối ưu dòng tiền doanh nghiệp.",
//     products: [
//       {
//         name: "Thẻ Doanh Nghiệp Cơ Bản",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "Miễn phí năm đầu",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//       {
//         name: "Corporate Plus",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "999.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//     ],
//   },
//   4: {
//     title: "Visa Sinh Viên",
//     description: "Tiện lợi, dễ đăng ký, hỗ trợ tài chính cho sinh viên.",
//     products: [
//       {
//         name: "Thẻ Sinh Viên Smart",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "99.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//       {
//         name: "Thẻ Học Tập Toàn Diện",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "Miễn phí",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//     ],
//   },
//   5: {
//     title: "Visa Premium",
//     description: "Đặc quyền dành cho khách hàng cao cấp.",
//     products: [
//       {
//         name: "Premium Gold",
//         benefits: [
//           "Tích điểm cao cho mọi giao dịch chi tiêu",
//           "Hoàn tiền không giới hạn theo hạng mục ưu tiên",
//           "Ưu đãi đặc biệt tại chuỗi khách sạn, resort 4-5 sao",
//           "Ưu tiên đặt chỗ và check-in tại sân bay",
//           "Miễn phí thường niên năm đầu cho khách hàng mới",
//           "Tặng gói bảo hiểm du lịch toàn cầu trị giá 100 triệu đồng"
//         ],
//         gia: "1.200.000đ/năm",
//         image: "/img/premium/4.png",
//         discsount: "-20%",
//       },
//       {
//         name: "Thẻ Black Diamond",
//           benefits: [
//           "Dịch vụ Concierge 24/7 toàn cầu",
//           "Tặng gói bảo hiểm toàn diện đến 1 tỷ đồng",
//           "Truy cập phòng chờ hạng thương gia tại 1.300+ sân bay",
//           "Tăng hạng ưu đãi tại đối tác khách sạn quốc tế (Marriott, Hyatt...)",
//           "Tích lũy điểm thưởng đổi chuyến bay, nghỉ dưỡng",
//           "Miễn phí phát hành và thay thế thẻ",
//           "Quản lý tài chính cá nhân và doanh nghiệp song song"
//         ],
//         gia: "2.500.000đ/năm",
//         image: "/img/premium/1.png",
//         discsount: "-40%",
//       },
//     ],
//   },
// };



export default function ChiTietSanPham() {
  const { cardId } = useParams();
  const card = CARD_MAP[parseInt(cardId)];
  const navigate = useNavigate();
  if (!card) return <p>Không tìm thấy loại thẻ.</p>;

  return (
    <div className="bg-white min-h-screen font-sans text-gray-900">
        <Navbar />
      <div className="max-w-7xl mt-12 mx-auto px-6 pt-8">
        {/* Breadcrumb */}
        <nav className="flex items-center text-lg text-black space-x-2 mb-2">
          <Home size={24} />
          <span>&gt;</span>
          <Link to="/san-pham" className="text-black hover:underline">Sản phẩm</Link>
          <span>&gt;</span>
          <span className="font-semibold">{card.title}</span>
        </nav>

        {/* Tiêu đề */}
        <h1 className="text-4xl font-bold text-gray-900 tracking-tight mb-2">{card.title}</h1>
        <p className="text-gray-600 mb-6">{card.description}</p>

        {/* Danh sách sản phẩm */}
        <div className="space-y-8">
          {card.products.map((item, idx) => (
            <div
              key={idx}
              onClick={() => navigate(`/product/${item.slug}`)}
              className="flex flex-col md:flex-row items-stretch bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden"
            >
              {/* Hình ảnh bên trái */}
              <div className="relative w-full md:w-2/5 h-56 md:h-auto">
                <img
                  src={item.image}
                  alt={item.name}
                  className="text-2xl object-cover w-full h-full"
                />
                {item.discount && (
                  <div className="absolute top-0 left-0 bg-red-600 text-white text-sm font-semibold px-3 py-1 rounded-br-xl">
                    {item.discount}
                  </div>
                )}
              </div>

              {/* Nội dung bên phải */}
              <div className="flex-1 p-6 flex flex-col justify-between">
                <div>
                  <h2 className="text-2xl font-bold mb-2">{item.name}</h2>
                  <ul className="text-base text-gray-600 mb-4 list-disc list-inside leading-relaxed">
                    {item.benefits.map((text, i) => (
                      <li key={i}>{text}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex justify-between items-end mt-auto">
                  <p className="text-sm">
                    <span className="text-xl text-gray-500">Giá chỉ từ: </span>
                    <span className="text-xl text-red-600 font-bold">{item.gia}</span>
                  </p>
                  <button className="bg-red-600 hover:bg-red-700 text-white text-sm font-medium px-5 py-2 rounded-full transition">
                    Đăng ký ngay
                  </button>
                </div>
              </div>
            </div>
          ))}
          {/* {selectedProduct && (
            <SanPhamMoTaChiTiet product={selectedProduct} />
          )} */}
        </div>
      </div>
    </div>
  );
}
