-- AlterTable
ALTER TABLE `user` MODIFY `address` VARCHAR(191) NULL;
