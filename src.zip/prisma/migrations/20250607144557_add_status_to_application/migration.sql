-- AlterTable
ALTER TABLE `visaapplication` ADD COLUMN `status` VARCHAR(191) NOT NULL DEFAULT 'Chờ duyệt';
